#ifndef WORKER_H
#define WORKER_H

void run_worker();

#endif // WORKER_H
