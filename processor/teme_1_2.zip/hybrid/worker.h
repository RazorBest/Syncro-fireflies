#ifndef WORKER_H
#define WORKER_H

void run_worker(int n_threads);

#endif // WORKER_H
